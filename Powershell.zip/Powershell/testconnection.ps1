﻿
foreach($computer in (Get-Content C:\FinalAdlist.txt))

{ 

if(-not (Test-Connection $computer -Count 1 -ErrorAction SilentlyContinue -ErrorVariable +Perror))

{
Add-Content C:\name_test.txt $Perror

}

else{Add-Content C:\required_servers.txt $computer}

}

