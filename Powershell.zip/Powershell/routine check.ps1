﻿

$computername=Read-Host "Enter the computername"

if(Test-Connection -computername $computername -ErrorAction SilentlyContinue)
 { Invoke-Command -ComputerName $computername -ScriptBlock {

$os=Get-WmiObject win32_operatingsystem

Start-sleep -Seconds 02
$boottime=$os.ConvertToDateTime($os.LastBootUpTime)
Start-sleep -Seconds 02
$Uptime = $OS.ConvertToDateTime($OS.LocalDateTime) - $boottime
Start-sleep -Seconds 02
$disk=Get-WmiObject win32_logicaldisk
Start-sleep -Seconds 02
$CPUInfo=Get-WmiObject win32_processor |  
Measure-Object -property LoadPercentage -Average | Select Average 
Start-sleep -Seconds 02
$Memory=gwmi -Class win32_operatingsystem  | 
Select-Object @{Name = "MemoryUsage"; 
Expression = {“{0:N2}” -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize)}}
Start-sleep -Seconds 02

$logName = Read-Host "Choose the logname : Security,System,Application,Setup" 

Write-Host "The date & time should be entered in this format 'MM/DD/YYYY HR:MIN:SEC pm'" -ForegroundColor Yellow

Start-Sleep -Seconds 04

[datetime]$After= Read-Host "Enter the logtime after a particular time" 
[datetime]$Before=Read-Host "Enter the logtime beofre a particular time" 
#$eventid= Read-Host "this is optional or you can enter the event id" 

$Eventlogs=Get-EventLog -LogName $logName  -After $After -Before $Before

Write-Host "The boot time is "$boottime""
Write-Host "The up time is "$Uptime""
Write-Host "The disk info is ""$disk"
Write-Host "The CPU  info is ""$CPUInfo"
Write-Host "The CPU  info is ""$Memory"
Write-Host "The eventlogs are  ""$Eventlogs"
}
}




else
{
Write-Host " The server is not available"
}