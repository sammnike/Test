﻿##################################################################################################################################
# WAPinventory.ps1
#
# v1.3
#
# This script performes an inventory of all external urls configured in the WAP configuration.
#
# The external IP of the WAP and the IP used in (external) DNS are compared to find possible configuration issues.
# The output CSV contains the following fields: "Name","PSComputerName","ExternalUrl","ExternalPreauthentication","ClaimsProviderName","BackendServerUrl","CertSubject","ServerIP","DNSIP","IPDNSmatch"
# The environment is detected by the script and included in the CSV name.
##################################################################################################################################

# Directory to store output CSV file
$CSVDIR = "C:\TEMP\"         # include de trailing '\'

##################################################################################################################################

# Check local IP adres to determine PostNL environment (A/P/T), the environment name is used in the CSV name
$IP = (Get-NetIPAddress | ? { $_.AddressFamily -eq "IPv4" -and $_.PrefixOrigin -eq "DHCP" } | select -First 1).IPAddress
# Stop if no local IPv4 address using DHCP is found
IF( !$IP )
{
    Write-Host "Cannot determine PostNL environment through local IP address" -ForegroundColor Red
    break
}
# Check if IP address is from PostNL Production environment
IF( [int]$IP.Split(".")[0] -eq 10 -and [int]$IP.Split(".")[1] -eq 245 -and [int]$IP.Split(".")[2] -ge 0 -and [int]$IP.Split(".")[2] -le 63 )
{
    $DetectedEnv = "PostNLProduction"
}
# Check if IP address is from PostNL Acceptance environment
elseIF( [int]$IP.Split(".")[0] -eq 10 -and [int]$IP.Split(".")[1] -eq 245 -and [int]$IP.Split(".")[2] -ge 64 -and [int]$IP.Split(".")[2] -le 127 )
{
    $DetectedEnv = "PostNLAcceptance"
}
# Check if IP address is from PostNL Test environment
elseIF( [int]$IP.Split(".")[0] -eq 10 -and [int]$IP.Split(".")[1] -eq 245 -and [int]$IP.Split(".")[2] -ge 128 -and [int]$IP.Split(".")[2] -le 191 )
{
    $DetectedEnv = "PostNLTest"
}
# Unable to determine environment, use default machine names
else
{
    Write-Host "Cannot determine PostNL environment through local IP address" -ForegroundColor Red
    break
}
# Write current environment to screen
Write-Host "$($DetectedEnv) environment detected" -ForegroundColor yellow

# Use Environment in CSV name
$CSVfilename = "$($CSVDIR)WAPinventory-$($DetectedEnv)-$(Get-Date -Format "yyyyMMddHHmm").csv"

# Check AD for computernamers that match a ADFS name and have a recent LoastLogon date (to prevent checking old computer accounts)
$ADFSServers = Get-ADComputer -Filter { name  -like "*ADFS*"} -Properties Name,LastLogon | Select-Object Name,@{n='LastLogon';e={[DateTime]::FromFileTime($_.LastLogon)}} | ? { (NEW-TIMESPAN –Start $_.lastlogon –End (Get-Date)).Days -le 31 } | select Name, ExternalIP
# Stop if Get-ADcomputer did not find any matching servers
IF( !$ADFSServers)
{
    Write-Host "Could not get a list of ADFS servers from AD, exiting." -ForegroundColor Red
    break
}
# Get the ClaimProviders for every RelayingParty fro the first ADFS server
$ClaimsProviders = Invoke-Command -ComputerName $ADFSServers[0].Name -ScriptBlock { Get-AdfsRelyingPartyTrust } | select Name, ClaimsProviderName
IF( !$ClaimsProviders)
{
    Write-Host "Could not get a list of ClaimsProviders from $($ADFSServers[0].Name), exiting." -ForegroundColor Red
    break
}

# Check AD for computernamers that match a WAP name and have a recent LoastLogon date (to prevent checking old computer accounts)
$WAPServers = Get-ADComputer -Filter { name  -like "*WAP*"} -Properties Name,LastLogon | Select-Object Name,@{n='LastLogon';e={[DateTime]::FromFileTime($_.LastLogon)}} | ? { (NEW-TIMESPAN –Start $_.lastlogon –End (Get-Date)).Days -le 31 } | select Name, ExternalIP
# Stop if Get-ADcomputer did not find any matching servers
IF( !$WAPServers)
{
    Write-Host "Could not get a list of WAP servers from AD, exiting." -ForegroundColor Red
    break
}

# Get the external IP of all the WAP servers
Write-Host "Checking external IP's." -ForegroundColor Yellow
foreach( $Server in $WAPServers )
{
    $ExternalIp = Invoke-Command -ComputerName $Server.Name -ScriptBlock { $webclient = New-Object System.Net.WebClient; ($($($webclient.DownloadString("http://checkip.dyndns.com")).Split(":")[1]).Split("<")[0]).Trim() }
    $Server.ExternalIP = $ExternalIp
    Write-Host "$($Server.Name) has IP $($ExternalIp)." -ForegroundColor Green
}


# Read the WAP config from the first WAP server. Every WAP server contains the complete WAP config
$WAPconfig = Invoke-Command -ComputerName $WAPServers[0].Name -ScriptBlock { Get-WebApplicationProxyApplication | select *, ExternalIP, BackendServerDNSname, BackendServerIP, BackendServerDNSType,ClaimsProviderName }
# Stop when no WAP configuration is found
IF( !$WAPconfig )
{
    Write-Host "Could not get the WAP config from server $($WAPServers[0].Name), exiting." -ForegroundColor Red
    break
}

# Enrich the WAP configuration with external IP etc.
Write-Host "Enriching WAP data." -ForegroundColor Yellow
foreach( $obj in $WAPconfig )
{
    # Enrich with the ClaimsProviderNames from the ADFS server
    $obj.ClaimsProviderName = "$(($ClaimsProviders | ? { $_.Name -like $obj.ADFSRelyingPartyName }).ClaimsProviderName -join '|')"

    IF( $obj.ClaimsProviderName -notlike $null)
    {
        Write-Host "`'$($obj.Name)`' uses ClaimsProviders $($obj.ClaimsProviderName)." -ForegroundColor Yellow
    }
    else
    {
        Write-Host "`'$($obj.Name)`' does not use a ClaimsProvider." -ForegroundColor Yellow
    }

    # Write-Host $obj.Externalurl
    # Convert url to a dns name
    # Resolve the url to an IP
    # Write-Host "Resolving url's to external ip's'" -ForegroundColor Yellow
    $DnsName = $obj.Externalurl.split("/")[2]
    $ExternalIP = Resolve-DnsName -Name $DnsName -Server "8.8.8.8" -DnsOnly -NoHostsFile -ErrorAction SilentlyContinue
    IF( $ExternalIp.count -eq 0 )
    {
        $obj.externalIP = ""
        $obj.BackendServerDNSType = ""
        Write-Host "$($obj.Externalurl) cannot be resolved by DNS servver 8.8.8.8." -ForegroundColor Red
    }
    else
    {
        $obj.externalIP = $ExternalIP.IP4Address
        Write-Host "$($obj.Externalurl) points to IP $($ExternalIP.IP4Address)." -ForegroundColor Green
    }

    # Write-Host $obj.BackendServerUrl
    # Resolve DNS name backend server remove https://, port number etc from backendservrurl
    $InternalDNSResult = Resolve-DnsName -Name (($obj.BackendServerUrl).split('/')[2]).split(":")[0] -DnsOnly -NoHostsFile -Type A -ErrorAction SilentlyContinue
    if ( $InternalDNSResult.count -eq 0 )
    {
        $obj.BackendServerDNSname = ""
        $obj.BackendServerIP = ""
        Write-Host "Host for BackendServerUrl $($obj.BackendServerUrl) cannot be resolved by the internal DNS server" -ForegroundColor Red
    }
    else
    {
        # Use Namehost field if it exists, if not use Name field
        IF( $InternalDNSResult[$InternalDNSResult.count - 1].NameHost -like $null )
        {
            $obj.BackendServerDNSname = $InternalDNSResult[$InternalDNSResult.count - 1].Name
            #$obj.BackendServerDNSType = $InternalDNSResult[$InternalDNSResult.count - 1].Type
        }
        else
        {
            $obj.BackendServerDNSname = $InternalDNSResult[$InternalDNSResult.count - 1].NameHost
            #$obj.BackendServerDNSType = $InternalDNSResult[$InternalDNSResult.count - 1].Type
        }
        $obj.BackendServerIP = $InternalDNSResult[$InternalDNSResult.count - 1].IP4Address
        # IF BackendServerDNSname is different from 'hostname' derived from the url then the DNS record is a CNAME
        IF( $obj.BackendServerDNSname -notlike (($obj.BackendServerUrl).split('/')[2]).split(":")[0] )
        {
            $obj.BackendServerDNSType = "CNAME"   
        }
        else
        {
            $obj.BackendServerDNSType = "A" 
        }
        Write-Host "Host for BackendServerUrl $($obj.BackendServerUrl) resolves to $($obj.BackendServerDNSname) with IP $($obj.BackendServerIP)" -ForegroundColor Green

    }
}

# Create an empty array for storing all the WAP configs per server
$WAPinventory = @()
# Check if a certificate in the WAP config exists on a server
foreach( $Server in $WAPServers )
{
    Write-Host "Processing server $($Server.Name)." -ForegroundColor Yellow
    $Certs = $null
    $Certs = Invoke-Command -ComputerName $Server.Name -ScriptBlock { dir Cert:\LocalMachine\My }
    # Check if any certs are returned
    if( !$Certs )
    {
        Write-Host "Unable to retrieve certs from server $($Server.Name)." -ForegroundColor Red
        break
    }
    # Check if a certificate is found for a WAP rule
    foreach( $Cert in $Certs )
    {
        # check if the certificate is found
        $Matches = $WAPconfig | ? { $Cert.Thumbprint -eq $_.ExternalCertificateThumbprint }
        foreach( $Match in $Matches )
        {
            $Inventoryobj = New-Object -TypeName PSObject
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name Name -Value $match.Name
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name PSComputerName  -Value $Server.Name
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name ExternalUrl  -Value $Match.ExternalUrl
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name ExternalPreauthentication  -Value $Match.ExternalPreauthentication
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name ClaimsProviderName  -Value $Match.ClaimsProviderName            
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name BackendServerUrl -Value $Match.BackendServerUrl
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name BackendServerDNSname -Value $Match.BackendServerDNSname
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name BackendServerIP -Value $Match.BackendServerIP
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name BackendServerDNSType -Value $Match.BackendServerDNSType
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name CertSubject  -Value $Cert.Subject
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name ServerIP  -Value $Server.ExternalIP
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name DNSIP  -Value $Match.ExternalIP
            Add-Member -InputObject $Inventoryobj -MemberType NoteProperty -Name IPDNSmatch  -Value ( $Match.ExternalIP -eq $Server.ExternalIP )

            # Add matched rule to the list
            $WAPinventory += $Inventoryobj 
        }   
    }
}

# Export to CSV
Write-Host "Exporting $($WAPinventory.Count) records to file $CSVfilename." -ForegroundColor Green
$WAPinventory | Export-CSV -Path $CSVfilename -NoClobber -NoTypeInformation