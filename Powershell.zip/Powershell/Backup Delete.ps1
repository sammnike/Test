﻿$Now = Get-Date
$Days = "5" #----- define amount of days ----#
$Targetfolder = "H:\HVRLandingzone\Old\archieve\" #----- define folder where files are located ----#
$Extension = "*.bak" #----- define extension ----#
$Lastwrite = $Now.AddDays(-$Days)

#----- Get files based on lastwrite filter and specified folder ---#
$Files = Get-Childitem $Targetfolder -include $Extension -Recurse | where {$_.LastwriteTime -le "$Lastwrite"}

foreach ($File in $Files)
{
    if ($File -ne $Null)
    {
        #write-host "Deleting File $File.Name" -foregroundcolor "DarkRed"
        Remove-item $File.Fullname | out-null
    }
    else
    {
        $No = Write-Output "No more files to delete"
    }
}

$secpasswd = ConvertTo-SecureString 'Sogeti123' -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential (“hvr”, $secpasswd)
$smtpserver = "smtp.sendgrid.com" 
$body="Hello Team,

Below files are deleted from OLD folder

$Files

$No

Regards, 
SQL Team.
"
$Subject="Delete files on $Now "
Send-MailMessage -Subject $Subject -body $body -From "SQL@Team" -To "swapnil.b.naik@capgemini.com" -SmtpServer $smtpserver -Port 25 -Credential $mycreds