﻿$src = "F:\Samm\SQL_Status\log"
$dest = "F:\Samm\SQL_Status\Archieve"
$num=1

Get-ChildItem -Path $src -Filter *.csv -Recurse | ForEach-Object {
    $nextName = Join-Path -Path $dest -ChildPath $_.name
while(Test-Path -Path $nextName)
    {
       $nextName = Join-Path $dest ($_.BaseName + "($num)" + $_.Extension)    
       $num+=1   
    }
    $_ | Move-Item -Destination $nextName
}
$date=Get-Date -format "yyyy-MM-dd"
$outputFile="F:\Samm\SQL_Status\log\POSTNL_PROD_$date.csv"
$output="$DBServer,$DBname `n"
function SQL-data ($DBservers)
{

$query = "SELECT bcks.database_name,bckS.type, bckS.backup_start_date, bckS.backup_finish_date, convert(decimal(19,2),(bckS.backup_size *1.0) / power(2,20)) as [Backup Size(MB)],software_name, is_compressed, physical_device_name FROM  msdb.dbo.backupset bckS INNER JOIN msdb.dbo.backupmediaset bckMS ON bckS.media_set_id = bckMS.media_set_id INNER JOIN msdb.dbo.backupmediafamily bckMF ON bckMS.media_set_id = bckMF.media_set_id where bckS.type = 'D'  and bckS.backup_start_date > DATEADD(day, -2, CONVERT (date, SYSDATETIME()))ORDER BY bckS.backup_start_date DESC"
foreach($DBserver in $DBSERVERS)
{
    "      $DBServer      "  >> "F:\Samm\SQL_Status\log\POSTNL_PROD_$date.csv"
cd "C:\Program Files (x86)\Microsoft SQL Server\Client SDK\ODBC\110\Tools\Binn"
cmd /c ".\SQLCMD.EXE" -S $DBserver  -Q $query >> F:\Samm\SQL_Status\log\POSTNL_PROD_$date.csv
}  
}
$DBSERVERS = Get-Content "F:Samm\SQL_IaaS\PROD_name.txt"
SQL-data -DBserver $DBSERVERS 


#diff (cat f:\hvr\doc\hvrchannels_$seldate.csv) (cat f:\hvr\doc\hvrchannels_2016-10-07.csv)
<#$props=@{"SUM"=$output} 
$obj=New-Object -TypeName PSObject -Property $props | clip
$ans=Get-Clipboard -Format Text#>

$secpasswd = ConvertTo-SecureString 'Sogeti123' -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential (“hvr”, $secpasswd)
$smtpserver = "smtp.sendgrid.com" 
$body="Hello Team,
PFA of SQL backup Database job for PROD environment
Regards,
SQL Team.
"
$Subject="SQL backup Database job for POSTNL PROD env. $date "
$attachments="F:\Samm\SQL_Status\log\POSTNL_PROD_$date.csv"
Send-MailMessage -Subject $Subject -body $body -From "SQL@Team" -To "swapnil.b.naik@capgemini.com" -SmtpServer $smtpserver -Port 25 -Credential $mycreds -Attachments $attachments

 