﻿$user = "postnl\swapnil.naik" 
$pwd1 =  Get-Content -Path "F:\Samm\SQL_IaaS\securepassword.txt"
$pwd = ($pwd1 | ConvertTo-SecureString)
$Credential = New-Object System.Management.Automation.PSCredential $user, $pwd
$args = "F:\Samm\SQL_IaaS\SQL_IaaS_DBCount.ps1"
Start-Process powershell.exe -Credential $Credential -ArgumentList ("-file $args")