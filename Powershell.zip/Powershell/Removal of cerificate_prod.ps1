﻿(Get-ADComputer -Filter 'Name -like "*"').DNSHostName |Out-File -FilePath "D:\FullAdlist.txt"

############Sorting the servers {Removing the PAAS instances}##########

select-string -Path D:\FullAdlist.txt -Pattern '(\w{2}-\w*-\w+)|(\w{2}-\w*)|(\w*-\w*-\w*-\w+)' -AllMatches | % { $_.Matches } | % { $_.Value } |Out-File D:\FinalAdlist.txt



foreach($computer in (Get-Content D:\FinalAdlist.txt))

{ 

if(-not (Test-Connection $computer -Count 1 -ErrorAction SilentlyContinue -ErrorVariable +Perror))

{
Add-Content D:\name_test.txt $Perror

}

else{Add-Content D:\required_servers.txt $computer}

}

foreach($computer in (Get-Content D:\required_servers.txt))

{
Invoke-Command -ComputerName $comp { 
  # This is the personal certificate store
  $Store = Get-Item Cert:\LocalMachine\My
  # Which can be used to remove certificates once we find them
  Get-ChildItem Cert:\LocalMachine\My |
    Where-Object { $_.NotAfter -lt (Get-Date) } |Remove-Item

    $trusted=Get-ChildItem Cert:\LocalMachine\AuthRoot
    
    Get-ChildItem Cert:\LocalMachine\AuthRoot |
    Where-Object { $_.NotAfter -lt (Get-Date) } |Remove-Item 
     }
    }

    Remove-Item -Path D:\FinalAdlist.txt -Force
    Remove-Item -Path D:\FullAdlist.txt -Force