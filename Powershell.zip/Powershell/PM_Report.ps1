﻿$src = "F:\hvr\doc\logs"
$dest = "F:\HVR\doc\Archive\"
$num=1

Get-ChildItem -Path $src -Filter *.txt -Recurse | ForEach-Object {

    $nextName = Join-Path -Path $dest -ChildPath $_.name

    while(Test-Path -Path $nextName)
    {
       $nextName = Join-Path $dest ($_.BaseName + "($num)" + $_.Extension)    
       $num+=1   
    }

    $_ | Move-Item -Destination $nextName
}

$date=Get-Date -format "yyyy-MM-dd"
$DBUser="hvradmin"

function SQL-data ($DBserver, $DBUser,$DBPassword,$DBnames, $Filetype)
{

$query ="select * from hvr_channel c where exists (select 1 from hvr_job j where j.job_name like (c.chn_name + '%') and j.job_state != 'SUSPEND')"
foreach($DBname in $DBnames)
{
 "`n`n  ---- HVRListener: $DBname --- `n`n" >> "F:\hvr\doc\logs\$filetype.txt"
cd "C:\Program Files (x86)\Microsoft SQL Server\Client SDK\ODBC\110\Tools\Binn"
cmd /c ".\SQLCMD.EXE" -S $DBserver -d $DBname -U $DBUser -P $DBPassword -Q $query >> F:\hvr\doc\logs\$filetype.txt

}
    
}

#PRD1
$PRDDBfile1 = Get-Content "F:\hvr\doc\PRD.txt"
$EncryptedPW1 = Get-Content -Path "F:\HVR\doc\DO_CHANGE\Inter_PRD.txt"
$SecureString1 = ConvertTo-SecureString -String $EncryptedPW1
$Credentials1 = New-Object System.Management.Automation.PSCredential ($DBUser, $SecureString1)
$Password1 = $Credentials1.GetNetworkCredential().Password
SQL-data -DBserver "j0vf10a6ek.database.windows.net" -DBUser $DBUser -DBPassword $Password1  -DBnames $PRDDBfile1 -Filetype "Inter_PRD_$date"

#PRD_NEW
$PRDDBfile1 = Get-Content "F:\hvr\doc\PRD_NEW.txt"
$EncryptedPW1 = Get-Content -Path "F:\HVR\doc\DO_CHANGE\Inter_PRD.txt"
$SecureString1 = ConvertTo-SecureString -String $EncryptedPW1
$Credentials1 = New-Object System.Management.Automation.PSCredential ($DBUser, $SecureString1)
$Password1 = $Credentials1.GetNetworkCredential().Password
SQL-data -DBserver "j0vf10a6ek.database.windows.net" -DBUser $DBUser -DBPassword $Password1  -DBnames $PRDDBfile1 -Filetype "Inter_PRD_NEW_$date"

#ACC1
$ACCDBfile1 = Get-Content "F:\hvr\doc\ACC1.txt"
$EncryptedPW2 = Get-Content -Path "F:\HVR\doc\DO_CHANGE\inter_acc.txt"
$SecureString2 = ConvertTo-SecureString -String $EncryptedPW2
$Credentials2 = New-Object System.Management.Automation.PSCredential ($DBUser, $SecureString2)
$Password2 = $Credentials2.GetNetworkCredential().Password
SQL-data -DBserver "cmwqfbfalv.database.windows.net" -DBUser $DBUser -DBPassword $Password2 -DBnames $ACCDBfile1 -Filetype "Inter_ACC_$date"

#PRD2
$PRDDBfile2 = Get-Content "F:\hvr\doc\PRD1.txt"
$EncryptedPW3 = Get-Content -Path "F:\HVR\doc\DO_CHANGE\intra_prd.txt"
$SecureString3 = ConvertTo-SecureString -String $EncryptedPW3
$Credentials3 = New-Object System.Management.Automation.PSCredential ($DBUser, $SecureString3)
$Password3 = $Credentials3.GetNetworkCredential().Password
SQL-data -DBserver "h87azj4i26.database.windows.net" -DBUser $DBUser -DBPassword $Password3 -DBnames $PRDDBfile2 -Filetype "Intra_PRD_$date"

#ACC2
$ACCDBfile2 = Get-Content "F:\hvr\doc\ACC.txt"
$EncryptedPW4 = Get-Content -Path "F:\HVR\doc\DO_CHANGE\intra_acc.txt"
$SecureString4 = ConvertTo-SecureString -String $EncryptedPW4
$Credentials4 = New-Object System.Management.Automation.PSCredential ($DBUser, $SecureString4)
$Password4 = $Credentials4.GetNetworkCredential().Password
SQL-data -DBserver "qtjvr8qxry.database.windows.net" -DBUser $DBUser -DBPassword $Password4 -DBnames $ACCDBfile2 -Filetype "Intra_ACC_$date"

#diff (cat f:\hvr\doc\hvrchannels_$seldate.txt) (cat f:\hvr\doc\hvrchannels_2016-10-07.txt)
<#$props=@{"SUM"=$output} 
$obj=New-Object -TypeName PSObject -Property $props | clip
$ans=Get-Clipboard -Format Text#>

$secpasswd = ConvertTo-SecureString 'Sogeti123' -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential (“hvr”, $secpasswd)
$smtpserver = "smtp.sendgrid.com" 
$body="Hello Team,
PFA of HVR count for Inter-cloud and Intra-cloud PROD and ACCP environment
Regards, 
HVR Team.
"
$Subject="HVR count for $date "
$attachments="F:\hvr\doc\logs\Intra_ACC_$date.txt","F:\hvr\doc\logs\Inter_ACC_$date.txt" ,"F:\hvr\doc\logs\Inter_PRD_$date.txt" ,"F:\hvr\doc\logs\Intra_PRD_$date.txt" , "F:\hvr\doc\logs\Inter_PRD_NEW_$date.txt"
Send-MailMessage -Subject $Subject -body $body -From "Samm@HVRTeam" -To "avishek.kumar@capgemini.com","stuti.kaushal@capgemini.com" -Cc "sog_od_hvr.in@capgemini.com","harsh.lulla@capgemini.com" -SmtpServer $smtpserver -Port 25 -Credential $mycreds -Attachments $attachments



                