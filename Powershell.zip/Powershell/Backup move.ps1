﻿

$Now = Get-Date
$Days = "30" #----- define amount of days ----#
$Sfolder = "H:\HVRLandingzone\NavRB\"
$DFolder= "H:\HVRLandingzone\Old\archieve"
$Extension = "*.bak"
$Lastwrite = $Now.AddDays(-$Days)

#----- Get files based on lastwrite filter and specified folder ---#
$Files = Get-Childitem $Sfolder -include $Extension -Recurse | where {$_.LastwriteTime -le "$Lastwrite"}

foreach ($File in $Files)
{
    if ($File -ne $Null)
    {
        #write-host "Deleting File $File.Name" -foregroundcolor "DarkRed"
        MOVE-Item -Path $File.FullName -Destination $DFolder -force
    }
    else
    {
       $No = Write-Output "No more files to Move"
    }
}

$secpasswd = ConvertTo-SecureString 'Sogeti123' -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential (“hvr”, $secpasswd)
$smtpserver = "smtp.sendgrid.com" 
$body="Hello Team,

Below files are Moved to OLD folder

$Files

$No

Regards, 
SQL Team.
"
$Subject="Move files on $Now "
Send-MailMessage -Subject $Subject -body $body -From "SQL@Team" -To "swapnil.b.naik@capgemini.com" -SmtpServer $smtpserver -Port 25 -Credential $mycreds
