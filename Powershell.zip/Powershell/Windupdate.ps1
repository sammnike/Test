﻿<#

$d=Get-Content -Path D:\required_servers.txt

#$d="af-tridion-11","af-tridion-12","af-tridion-13","if-wap-1"

foreach($comp in $d){

$info=Invoke-Command -ComputerName $comp -ScriptBlock { Get-WindowsFeature | where-object {$_.Name -like "Web-Server" -and $_.Installed -eq $True}  }


$name=$info.PSComputerName
<#

#$dname=$info.DisplayName
$name=$info.Name
$state=$info.InstallState #>

<#$result="$($name)" 


Add-Content -Path C:\List.txt -Value $result 
} #>

$f=Get-Content -Path C:\Users\jimesh.sutar\Desktop\List_web.txt
foreach($c in $f){

$ans=invoke-command  -ComputerName $c -ScriptBlock {  Get-SilWindowsUpdate | Where-Object {$_.ID -like "KB4025335"} |Select ID ,PSComputerName }

IF(!$ans)
{
Write-Host "No update found"

Add-Content D:\servers_add.txt $c

}

else
{

$id=$ans.ID
$cname=$ans.PSComputerName

$final="$($id);$($cname)"
Add-Content D:\alreadydone.txt $final

}
}