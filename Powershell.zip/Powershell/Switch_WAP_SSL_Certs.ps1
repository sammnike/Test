﻿$ExternalCertificateThumbprint = Get-WebApplicationProxyApplication | Select Name, ExternalCertificateThumbprint | Out-GridView -Title "Select the current certificate" -PassThru

$NewCertThumbprint = Get-ChildItem Cert:\LocalMachine\My | select Subject, Thumbprint, NotBefore, NotAfter | Out-GridView -Title "Select the new certificate" -PassThru

$Apps = Get-WebApplicationProxyApplication | Where{$_.ExternalCertificateThumbprint -eq $ExternalCertificateThumbprint.ExternalCertificateThumbprint}

ForEach ($App in $apps){
    Set-WebApplicationProxyApplication –ID $App.ID -ExternalCertificateThumbprint $NewCertThumbprint.Thumbprint -Verbose

    $wait = Read-Host -Prompt "Press enter to continue"
}