﻿
Add-AzureAccount

Get-AzureSubscription | select SubscriptionId, SubscriptionName

Select-AzureSubscription -SubscriptionName "PostNL Sogeti-A1"

# Database to export
$DatabaseName = "postNL-APISDB1-A_old"
$ServerName = "fwzgm4aurt.database.windows.net"
$serverAdmin = "cloudapis"
$serverPassword = ""
$securePassword = ConvertTo-SecureString -String $serverPassword -AsPlainText -Force
$creds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $serverAdmin, $securePassword

# Generate a unique filename for the BACPA
$bacpacFilename = $DatabaseName + (Get-Date).ToString("yyyyMMddHHmm") + ".bacpac" 
out-file -filepath F:\APIS_ACCP_backup\$bacpacFilename


