﻿$connectionName = "AzureRunAsConnection" 
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

    "Logging in to Azure..."
    Login-AzureRmAccount `
        -ServicePrincipal `
        -TenantId $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 

}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}


$VMAF = @(Get-AzureRmVM | Where {$_.Tags.Count -gt 0 `
    -and $_.Tags.Keys -contains "ServerRole" `
    -and $_.Tags.Values -contains "af"})

Write-Output "$(Get-Date -Format hh:mm:ss) - INFO: Found [$($VMAF.Count)] schedule-tagged Frontend Virtual Machines in subscription" 
 
ForEach ($VM in $VMAF)
{
    Write-Output "Stopping: $($VM.Name)"
    Stop-AzureRMVM -Name $VM.Name -ResourceGroupName $VM.ResourceGroupName -Force
} 

Start-Sleep -s 1800

$VMDB = @(Get-AzureRmVM | Where {$_.Tags.Count -gt 0 `
    -and $_.Tags.Keys -contains "ServerRole" `
    -and $_.Tags.Values -contains "db"})

Write-Output "$(Get-Date -Format hh:mm:ss) - INFO: Found [$($VMDB.Count)] schedule-tagged Database Virtual Machines in subscription"

ForEach ($VM in $VMDB)
{
    Write-Output "Stopping: $($VM.Name)"
    Stop-AzureRMVM -Name $VM.Name -ResourceGroupName $VM.ResourceGroupName -Force
}     
