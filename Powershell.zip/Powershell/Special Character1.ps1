$allfiles = Get-ChildItem "F:\hvr\hvr_temp\hubdba1\ids\*.txt"

foreach ($files in $Allfiles)
{
Write-host "   Executing for file : $($files.name)" -f Green

$file = Get-Content "F:\hvr\hvr_temp\hubdba1\ids\$($files.name)"

if ($file | Select-String -Pattern  "?" ,"�" ,"�" ,"i" ,"�" ,"�" ,"�" ,"�" ,"�" ,"�" ,"�" ,"�" )
{

Write-Host "File : $($files.name) has special character" -ForegroundColor Yellow

}

else
{
Write-Host "File does not have letters"
}
 
}