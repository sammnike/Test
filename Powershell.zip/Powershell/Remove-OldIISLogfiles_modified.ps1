﻿$Logfiles = Get-ChildItem -Path "C:\inetpub\logs\LogFiles\*" -include "*.log" -Force -Recurse | where {$_.LastWriteTime -lt (Get-Date).AddMonths(-2)}
Add-Content -Path "C:\inetpub\logs\LogFiles\W3SVC2\Cleared-Logs.log" -Value $Logfiles
ForEach($File in $Logfiles){ Remove-Item -Path $File.FullName -Force }

$secpasswd = ConvertTo-SecureString 'Sogeti123' -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential (“hvr”, $secpasswd)
$smtpserver = "smtp.sendgrid.com"
$from = ("HVR-PROD@" + $env:computername)
$Subject = "Logfiles of the server removed"
$body=" Hello Team,

Logfiles of the w3svc folders are been cleared for server $env:computername in Production environment
    
Thanks & Regards,
Jimesh S."



Send-MailMessage -Subject $Subject -body $body -From "Jimesh@windows" -To "rob.koger@postnl.nl","sog_od_wintech_l2.in@capgemini.com","sushil.ingle@capgemini.com" -SmtpServer $smtpserver -Port 25 -Credential $mycreds
