﻿
<#######one time activity to encrypt the passowrd######


$password = read-host -prompt "Enter your Password" 
$secure = ConvertTo-SecureString $password -force -asPlainText 
$bytes = ConvertFrom-SecureString $secure 
$bytes | out-file "C:\test1.txt" #>



############Getting the credentials############
<#$EncryptedPW = Get-Content -Path "C:\test1.txt" 
$SecureString = ConvertTo-SecureString -String $EncryptedPW 
$Credentials = New-Object System.Management.Automation.PSCredential "Postnl\jimesh.sutar", $SecureString #>

###########Getting list of all the computers##########
#$Credentials=Get-Credential
$server="if-wap-1","af-tridion-12","af-tridion-11","af-tridion-13"
#$date = (Get-Date).AddYears(-1)

############Sorting the servers {Removing the PAAS instances}##########

#select-string -Path C:\FullAdlist.txt -Pattern '(\w{2}-\w*-\d)|(\w*-\w*-\w*-\d)' -AllMatches | % { $_.Matches } | % { $_.Value } |Out-File C:\FinalAdlist.txt

###### The Removal of certificates #############

foreach($comp in $server){



Invoke-Command -ComputerName $comp  -ScriptBlock {


Get-ChildItem -Path cert:\localmachine\my | Where-Object { $_.NotAfter -lt ((Get-Date).AddYears(-1))} |Export-Certificate -FilePath C:\Personal.cer



get-childitem -path cert:\LocalMachine\AuthRoot | Where-Object {$_.NotAfter -lt ((Get-Date).AddYears(-1))} |Export-Certificate -FilePath C:\Trusted.cer

get-childitem -path cert:\LocalMachine\AuthRoot | Where-Object {$_.NotAfter -lt ((Get-Date).AddYears(-1))} |Remove-Item

Get-ChildItem -Path cert:\localmachine\my | Where-Object { $_.NotAfter -lt ((Get-Date).AddYears(-1))} |Remove-Item

}} 

#Foreach($a in $Personal){Remove item}


#Foreach($b in $trusted){Remove item}





 



Exit-PSSession