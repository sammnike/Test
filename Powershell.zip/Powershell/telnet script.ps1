﻿$servers= Get-Content -Path "C:\required_servers.txt"

foreach($s in $servers){
If (New-Object System.Net.Sockets.TCPClient -ArgumentList $s,5985) { Write-Host 'YES' }

else{Write-Host $s}
#If ($? -eq $false) { Write-Host 'NO' }
}

