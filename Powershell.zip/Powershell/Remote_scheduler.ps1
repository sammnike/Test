﻿########################## SCHEDULING REMOTELY############################

#Description:This script with remotely schedule the tasks in task scheduler
#Version:1.0
#Author:Jimesh sutar
#Script_Name : Remote_scheduler
##########################################################################

$SN= gc -Path "F:\my scripts_test\tridion.txt"


foreach($S in $SN)
{

#Test connectivity
#Test-Connection -ComputerName $S -Count 2


##Copy paste the files from one stepstone to the server

Copy-Item -Path "F:\my scripts_test\Remove-OldIISLogfiles_modified.ps1" -Destination "\\$S\F$" -Force

#setup the task
$action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument '-ExecutionPolicy Unrestricted F:\Remove-OldIISLogfiles_modified.ps1'
$trigger =  New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At 5pm

Register-ScheduledTask -CimSession $S -TaskName "removal logfiles" -Description "Removal of files" -RunLevel Highest -Trigger $trigger -Action $action -User System -Force

}