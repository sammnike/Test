﻿$ErrorLog = ".\Get-AD-Certificates-error.log"

#$C=get-adcomputer -filter * | ForEach-Object {$_.Name}

$C = (Get-ADComputer -Filter * -Properties Name,LastLogon | ? { $_.DistinguishedName -notlike "*Remote App*" } | Select-Object Name,@{n='LastLogon';e={[DateTime]::FromFileTime($_.LastLogon)}} )

foreach($obj in $C.Name) {
            Write-Host $obj
            $certs = $null
            $certs = Invoke-Command -ComputerName $obj -scriptblock { Get-ChildItem CERT:LocalMachine/My -ExpiringInDays 730 } | select Subject,DnsNameList,Thumbprint,NotBefore,NotAfter,Issuer,PSComputerName
            # Log if no certificates can be found
            IF( !$certs )
            {
                Write-Host "No certificates found on $($obj), investigation needed." -ForegroundColor Red
                "No certificates found on $($obj), investigation needed." | Out-File -FilePath $ErrorLog -Append  
            }
            
             
            foreach($cert in $certs) 
            {

                $subject = $cert.Subject
                $DnsNameList = $cert.DnsNameList

                # Create a string separated with ; for all dnsnames
                [int]$count=0
                [string]$DnsNameList = ""
                foreach( $obj in $cert.DnsNameList.unicode )
                {
                    write-host "obj=$($obj)"
                    # first DNS name
                    if( $count -eq 0 )
                    {
                        $CN = $obj.Split(',')[0]
                    }
                    if( $count -gt 0)
                    {
                        $DnsNameList = "$($DnsNameList);"
                    }
                    $DnsNameList = $DnsNameList+$obj
                    $count++
                }

                 $myArray = "file1.csv","file2.csv","file3.csv"
                    '"' + ($myArray -join '";"') + '"'  
 
                
                $thumbprint = $cert.Thumbprint
                $notbefore = $cert.NotBefore
                $notafter = $cert.NotAfter
                $issuer = $cert.Issuer
                $relatedci = $cert.PSComputername
                $type = If($cert.Issuer -like "*QuoVadis*" -or $cert.Issuer -like "*Verisign*"){"External"} Else {"Internal"}
                $Date = (Get-Date -UFormat %D)
                $inventorycomment = 'Manual inventory'+' '+ $Date
        
                if ($CN -eq $DnsNameList) {
                $DnsNameList = "Not a SAN Certificate"
                } 
                


        
        $result = "$($CN);$($Subject);$($DnsNameList);$($thumbprint);$($notbefore.ToString("dd-mm-yyyy"));$($notafter.ToString("dd-mm-yyyy"));`"$($issuer)`";$($type);$($relatedci);$($inventorycomment)"
        
    
         Add-Content C:\Temp\CertInventoryMASTER_Prod.csv $result
         write-host $result | FL
         write-host `n
         }
         

        }
