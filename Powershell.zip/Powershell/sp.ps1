﻿
$date=Get-Date -format "yyyy-MM-dd"
$DBUser = "cloudapis"

function SQL-data ($DBserver, $DBUser,$DBPassword,$DBnames)
{

$query ="exec dbo.UpdateBLSBedrijfslocatie"
foreach($DBname in $DBnames)
{
cd "C:\Program Files (x86)\Microsoft SQL Server\Client SDK\ODBC\110\Tools\Binn"
cmd /c ".\SQLCMD.EXE" -S $DBserver -d $DBname -U $DBUser -P $DBPassword -Q $query >> F:Samm\SQL_IaaS\SP\SP_$date.txt
 }   
}

$PRDDBfile1 = "postnl-apisdb1"
$EncryptedPW1 = Get-Content -Path "F:\Samm\SQL_IaaS\SP\PWD.txt"
$SecureString1 = ConvertTo-SecureString -String $EncryptedPW1
$Credentials1 = New-Object System.Management.Automation.PSCredential ($DBUser, $SecureString1)
$Password1 = $Credentials1.GetNetworkCredential().Password
SQL-data -DBserver "l2nkvco412.database.windows.net" -DBUser $DBUser -DBPassword $Password1  -DBnames $PRDDBfile1

$secpasswd = ConvertTo-SecureString 'Sogeti123' -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential (“hvr”, $secpasswd)
$smtpserver = "smtp.sendgrid.com" 
$body="Hi team,
SP UpdateBLSBedrijfslocatie run, please refer attachment
Regards, 
SQL Team.
"
$Subject="SQL SP (APIS PROD) run on $date "
$attachments="F:Samm\SQL_IaaS\SP\SP_$date.txt"
Send-MailMessage -Subject $Subject -body $body -From "SQL@Team" -To "swapnil.b.naik@capgemini.com","ravindra.rajage@capgemini.com","nilesh.kakad@capgemini.com" -SmtpServer $smtpserver -Port 25 -Credential $mycreds -Attachments $attachments

