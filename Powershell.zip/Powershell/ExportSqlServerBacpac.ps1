<#
	The sample scripts are not supported under any Microsoft standard support 
	program or service. The sample scripts are provided AS IS without warranty  
	of any kind. Microsoft further disclaims all implied warranties including,  
	without limitation, any implied warranties of merchantability or of fitness for 
	a particular purpose. The entire risk arising out of the use or performance of  
	the sample scripts and documentation remains with you. In no event shall 
	Microsoft, its authors, or anyone Else involved in the creation, production, or 
	delivery of the scripts be liable for any damages whatsoever (including, 
	without limitation, damages for loss of business profits, business interruption, 
	loss of business information, or other pecuniary loss) arising out of the use 
	of or inability to use the sample scripts or documentation, even If Microsoft 
	has been advised of the possibility of such damages 
#>

$ErrorActionPreference = 'Stop'

# 0. Prepare database name and backup file Name
$ServerInstance = "<Server Instance Name, e.g. localhost>"
$DatabaseName = "<Target Database Name, e.g. Northwind>"
$BackupFilePath = "<Backup file full disk path, e.g. D:\backup.bacpac>"

Try {
# 1. Get SQL Server Version
	$SQLKey = Get-ItemProperty "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"  
	$SQLVersionNum = [regex]::Match($SQLKey.MSSQLSERVER, "\d\d").Value

# 2. Construct SqlPackage Path
	$ToolPath = "C:\Program Files (x86)\Microsoft SQL Server\$($SQLVersionNum)0\DAC\bin"
	$OldPath = Get-Location
	Set-Location $ToolPath

# 3. Run SqlPackage tool to export bacpac file
	.\SqlPackage.exe /a:Export /ssn:$ServerInstance /sdn:$DatabaseName /tf:$BackupFilePath

	Set-Location $OldPath.Path
} Catch {
	Throw $_
}
